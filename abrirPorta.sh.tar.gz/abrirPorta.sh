#!/bin/bash

echo "Iniciando porta"

IperfServidor() {
	(iperf3 -s -p 5010 ) 
}

main() {
IperfServidor

wait "$PID"
echo "Fim do teste"

}

main "$@"

